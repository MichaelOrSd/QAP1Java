// Programer: Michael O'Reilly
// Date: 16/05/2022
/* 
* Q1. How many hours?
*     17/05/2022 - Problem1: 0630-0800, 1000-1030 (2hrs)
*     18/05.2022 - Problem2: 1200-1400, 1600-1630, (3.5hrs)
* Q2. what online resources?
*     None.
* Q3. Friends help?
*     Yes, I clarified a few things with Stephen.
* Q4. Instructors help?
*     Yes, I reached out to Ainee for clarification.
* Q5. Question rating? (1-5)
*     Problem 1: (3/5)
*     Problem 2: (4/5)
*/ 